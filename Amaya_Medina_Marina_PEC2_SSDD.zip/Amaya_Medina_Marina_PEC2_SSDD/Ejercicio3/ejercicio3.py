import threading
import time
import random
import hashlib

#Parámetros globales
num_nodes = 4
target_blocks = 12
stake = {
    1: 50,
    2: 30,
    3: 20
}
mutex = threading.Lock()
blockchain = []

#Definición de la clase Block
class Block:
    def __init__(self, index, timestamp, block_hash, previous_hash, validator):
        self.index = index
        self.timestamp = timestamp
        self.block_hash = block_hash
        self.previous_hash = previous_hash
        self.validator = validator

#Función para la prueba de participación
def proof_of_stake():
    nodos = list(stake.keys())
    weights = list(stake.values())
    selected_node = random.choices(nodos, weights=weights, k=1)[0]
    return selected_node

#Función para generar el hash del bloque
def generar_hash_block(node_id, stake, timestamp, previous_hash):
    #Concatenamos los parámetros en formato hexadecimal
    node_id_hex = format(node_id, '08x')
    stake_hex = format(stake, '08x')
    timestamp_hex = format(int(timestamp), '016x')
    previous_hash_hex = previous_hash if previous_hash != "0" else "0"  #El hash previo, "0" si es el primer bloque
    
    #Concatenamos todos los elementos y los pasamos por sha256
    block_data = node_id_hex + stake_hex + timestamp_hex + previous_hash_hex
    return hashlib.sha256(block_data.encode('utf-8')).hexdigest()

#Función critical_section()
def critical_section(node_id, stake, mutex):
    print(f"Nodo {node_id} intentando acceder a la sección crítica.")
    timestamp = time.time()
    mutex.acquire()
    try:
        print(f"Nodo {node_id} ha adquirido el mutex en tiempo: {timestamp:.7f}, generando bloque...")
        
        #Obtener el bloque previo
        previous_block = blockchain[-1] if blockchain else None
        previous_hash = previous_block.block_hash if previous_block else "0"
        
        #Crear el nuevo bloque
        index = len(blockchain)
        
        #Generar el hash del nuevo bloque
        block_hash = generar_hash_block(node_id, stake, timestamp, previous_hash)
        
        #Crear una instancia del bloque
        new_block = Block(index, timestamp, block_hash, previous_hash, node_id)
        
        #Añadir el bloque a la cadena de bloques
        blockchain.append(new_block)
        
        print(f"Nodo {node_id} ha creado el bloque {index} con hash {block_hash}.")

        #Simulamos el trabajo con un tiempo aleatorio entre 1 y 2 segundos
        time.sleep(random.uniform(1, 2))

    finally:
        mutex.release()
        print(f"Nodo {node_id} ha liberado el semáforo.")

#Función que define el comportamiento de un nodo
def run_node(node_id, mutex):
    print(f"Nodo {node_id} iniciado.")
    
    while len(blockchain) < target_blocks:
        time.sleep(random.uniform(0.1, 0.5))
        if node_id == proof_of_stake(): #Verificamos si el nodo es seleccionado
            print(f"Nodo {node_id} ha sido seleccionado para producir un bloque.")
            critical_section(node_id, stake[node_id], mutex)

#Función principal para iniciar los nodos
def main():
    nodos = [threading.Thread(target=run_node, args=(i, mutex)) for i in range(num_nodes)] #Iniciar los procesos ligeros (nodos) en hilos
    
    for nodo in nodos: #Iniciar los hilos
        nodo.start()

    for nodo in nodos: #Esperar a que todos los nodos terminen su ejecución
        nodo.join()

    #Imprimir la cadena de bloques generada
    print("\nCADENA DE BLOQUES FINAL:")
    for block in blockchain:
        print(f"Índice: {block.index}")
        print(f"Timestamp: {block.timestamp:.7f}")
        print(f"Hash del bloque: {block.block_hash}")
        print(f"Productor del bloque: Nodo {block.validator}")
        print(f"Hash del bloque anterior: {block.previous_hash}")
        print()

if __name__ == "__main__":
    main()
