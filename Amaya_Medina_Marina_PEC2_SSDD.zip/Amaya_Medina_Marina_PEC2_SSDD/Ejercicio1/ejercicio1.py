import hashlib

def generate_ipfs_hash(input_string):
    input_bytes = input_string.encode('utf-8') #Convertir la cadena a bytes
    sha256_hash = hashlib.sha256(input_bytes) #Generar el hash utilizando SHA-256
    return sha256_hash.hexdigest() #Devuelve el hash en formato hexadecimal

input_string = input("Ingrese una cadena para generar el hash IPFS (SHA-256): ")
print("Hash generado:", generate_ipfs_hash(input_string))

